// Select the two elements we need to work with: the button and the navigation menu.
const menuToggle = document.querySelector('.menu-toggle');
const mainNav = document.querySelector('.main-nav');

// Check if both elements were found before adding the event listener.
if (menuToggle && mainNav) {
    // Add an event listener that waits for a 'click' on the menu toggle button.
    menuToggle.addEventListener('click', () => {
        // When the button is clicked, add or remove the 'nav-open' class from the navigation menu.
        // This class is what our CSS uses to show or hide the menu.
        mainNav.classList.toggle('nav-open');
    });
}

// --- TYPED.JS INITIALIZATION ---
if (document.getElementById('typed-target')) {
  var options = {
    strings: [
      'Of Cyber Security',
      'Of Ethical Hacking',
      ' Shadows Of Web'
    ],
    typeSpeed: 50,
    backSpeed: 25,
    backDelay: 1500,
    startDelay: 500,
    loop: true,
    showCursor: true,
    cursorChar: '_'
  };

  var typed = new Typed('#typed-target', options);
}

// --- AOS INITIALIZATION ---
AOS.init({
  duration: 800, // Animation duration in milliseconds
  once: true,    // Whether animation should happen only once
  offset: 50     // Offset (in px) from the original trigger point
});

